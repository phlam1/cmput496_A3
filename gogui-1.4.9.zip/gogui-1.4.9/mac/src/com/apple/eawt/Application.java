package com.apple.eawt;

/** Stub class for compiling net.sf.gogui.specialmac. */
public class Application
{
    public void addAboutMenuItem()
    {
    }

    public void addApplicationListener(ApplicationListener listener)
    {
    }

    public static Application getApplication()
    {
        return null;
    }

    public void removePreferencesMenuItem()
    {
    }

    public void setEnabledAboutMenu(boolean enable)
    {
    }
}
